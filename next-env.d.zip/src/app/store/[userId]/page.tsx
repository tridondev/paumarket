'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { useParams } from 'next/navigation';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/lib/auth-context';
import { useListings } from '@/hooks/useListings';
import ListingCard from '@/components/ListingCard';
import type { UserProfile } from '@/types';

export default function StorePage() {
  const params = useParams<{ userId: string }>();
  const { profile: myProfile } = useAuth();
  const [storeOwner, setStoreOwner] = useState<UserProfile | null | undefined>(undefined);
  const { listings, loading, error } = useListings(undefined, params?.userId);

  const [editing, setEditing] = useState(false);
  const [storeName, setStoreName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);

  const isOwner = myProfile?.uid === params?.userId;

  useEffect(() => {
    if (!params?.userId) return;
    getDoc(doc(db, 'users', params.userId)).then((snap) => {
      const data = snap.exists() ? (snap.data() as UserProfile) : null;
      setStoreOwner(data);
      setStoreName(data?.storeName || '');
      setBio(data?.bio || '');
    });
  }, [params?.userId]);

  async function handleSave(e: FormEvent) {
    e.preventDefault();
    if (!params?.userId) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', params.userId), { storeName, bio });
      setStoreOwner((prev) => (prev ? { ...prev, storeName, bio } : prev));
      setEditing(false);
    } finally {
      setSaving(false);
    }
  }

  if (storeOwner === undefined) {
    return <div className="max-w-6xl mx-auto px-4 py-20 text-center text-ink/50">Loading…</div>;
  }
  if (storeOwner === null) {
    return <div className="max-w-6xl mx-auto px-4 py-20 text-center text-ink/50">Store not found.</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex items-start justify-between gap-4 mb-10">
        <div>
          <p className="text-forest-600 text-sm font-medium mb-1">Student store</p>
          <h1 className="font-display text-3xl mb-2">
            {storeOwner.storeName || storeOwner.displayName}
          </h1>
          {storeOwner.storeName && (
            <p className="text-ink/50 text-sm mb-2">by {storeOwner.displayName}</p>
          )}
          <p className="text-ink/70 max-w-xl leading-relaxed">
            {storeOwner.bio || 'This seller has not added a store description yet.'}
          </p>
        </div>
        {isOwner && !editing && (
          <button onClick={() => setEditing(true)} className="btn-secondary shrink-0">
            Edit store
          </button>
        )}
      </div>

      {editing && (
        <form onSubmit={handleSave} className="card p-5 mb-10 flex flex-col gap-4 max-w-md">
          <div>
            <label className="label">Store name</label>
            <input className="field" value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder={storeOwner.displayName} />
          </div>
          <div>
            <label className="label">About your store</label>
            <textarea className="field min-h-[90px]" value={bio} onChange={(e) => setBio(e.target.value)} />
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? 'Saving…' : 'Save'}
            </button>
            <button type="button" onClick={() => setEditing(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      )}

      {error ? (
        <div className="text-center py-20 border border-dashed border-clay-500/30 bg-clay-500/5 rounded">
          <p className="text-clay-600 font-medium mb-1">Couldn&rsquo;t load listings</p>
          <p className="text-ink/50 text-sm max-w-md mx-auto">{error}</p>
          <p className="text-ink/40 text-xs mt-2">
            This is usually a missing Firestore index — check the browser console for a link to create it.
          </p>
        </div>
      ) : loading ? (
        <p className="text-ink/50 text-sm">Loading listings…</p>
      ) : listings.length === 0 ? (
        <p className="text-ink/50 text-sm">No active listings from this store yet.</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {listings.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      )}
    </div>
  );
}
