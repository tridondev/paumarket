'use client';

import Link from 'next/link';
import { useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';

const NAV_LINKS = [
  { href: '/', label: 'Shop' },
  { href: '/exchange', label: 'Exchange' },
  { href: '/leaving-pau', label: 'Leaving PAU' },
];

export default function Navbar() {
  const { user, profile, signOutUser } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');

  async function handleSignOut() {
    await signOutUser();
    router.push('/');
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    router.push(q.trim() ? `/?q=${encodeURIComponent(q.trim())}` : '/');
  }

  return (
    <header className="sticky top-0 z-40 bg-cream/95 backdrop-blur">
      {/* Utility bar — trust signal, thin, like a marketplace's top strip */}
      <div className="bg-forest-700 text-cream/80 text-xs">
        <div className="max-w-6xl mx-auto px-4 h-8 flex items-center justify-between">
          <span>Verified Pan-African University members only</span>
          <div className="hidden sm:flex items-center gap-4">
            <Link href="/leaving-pau" className="hover:text-cream transition-colors">
              Leaving PAU sales
            </Link>
            <Link href="/sell" className="hover:text-cream transition-colors">
              Start a student store
            </Link>
          </div>
        </div>
      </div>

      <div className="border-b border-forest-600/10">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center gap-4">
          <Link href="/" className="flex items-baseline gap-1.5 shrink-0">
            <span className="font-display italic text-xl font-semibold text-forest-600">
              PAU
            </span>
            <span className="font-display text-xl text-ink hidden sm:inline">Marketplace</span>
          </Link>

          <nav className="hidden lg:flex items-center gap-6 shrink-0">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`text-sm font-medium transition-colors whitespace-nowrap ${
                  pathname === link.href
                    ? 'text-forest-600'
                    : 'text-ink/70 hover:text-forest-600'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Search — the centerpiece, Amazon-style */}
          <form onSubmit={handleSearch} className="flex-1 min-w-0">
            <div className="relative">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40 pointer-events-none"
              >
                <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                <path d="M21 21l-4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              <input
                type="text"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search laptop, jacket, mini fridge, printing…"
                className="field !pl-9 !py-2 !rounded-pill"
              />
            </div>
          </form>

          <div className="hidden md:flex items-center gap-4 shrink-0">
            {user && profile ? (
              <>
                <Link
                  href="/messages"
                  className="text-sm font-medium text-ink/70 hover:text-forest-600 whitespace-nowrap"
                >
                  Messages
                </Link>
                {profile.isAdmin && (
                  <Link
                    href="/admin"
                    className="text-sm font-medium text-clay-500 hover:text-clay-600 whitespace-nowrap"
                  >
                    Admin
                  </Link>
                )}
                <Link
                  href={`/store/${profile.uid}`}
                  className="text-sm font-medium text-ink/70 hover:text-forest-600 whitespace-nowrap"
                >
                  My store
                </Link>
                <button onClick={handleSignOut} className="btn-secondary !px-4 !py-2 whitespace-nowrap">
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="text-sm font-medium text-ink/70 hover:text-forest-600 whitespace-nowrap">
                  Log in
                </Link>
                <Link href="/signup" className="btn-gold !px-4 !py-2 whitespace-nowrap">
                  Join
                </Link>
              </>
            )}
          </div>

          <button
            className="md:hidden text-ink shrink-0"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-forest-600/10 px-4 py-4 flex flex-col gap-3 bg-cream">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} onClick={() => setOpen(false)} className="text-sm font-medium text-ink/80">
              {link.label}
            </Link>
          ))}
          {user && profile ? (
            <>
              <Link href="/messages" onClick={() => setOpen(false)} className="text-sm font-medium text-ink/80">
                Messages
              </Link>
              <Link href={`/store/${profile.uid}`} onClick={() => setOpen(false)} className="text-sm font-medium text-ink/80">
                My store
              </Link>
              {profile.isAdmin && (
                <Link href="/admin" onClick={() => setOpen(false)} className="text-sm font-medium text-clay-500">
                  Admin
                </Link>
              )}
              <button onClick={handleSignOut} className="btn-secondary self-start !px-4 !py-2">
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link href="/login" onClick={() => setOpen(false)} className="text-sm font-medium text-ink/80">
                Log in
              </Link>
              <Link href="/signup" onClick={() => setOpen(false)} className="btn-gold self-start !px-4 !py-2">
                Join PAU Marketplace
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}
