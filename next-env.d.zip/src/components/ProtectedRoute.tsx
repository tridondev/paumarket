'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';

/**
 * Wrap any page that requires a signed-in, admin-approved user.
 * Redirects to /login (not signed in) or /pending-approval (not yet approved).
 */
export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace('/login');
      return;
    }
    if (profile && profile.status !== 'approved') {
      router.replace('/pending-approval');
    }
  }, [user, profile, loading, router]);

  if (loading || !user || !profile || profile.status !== 'approved') {
    return (
      <div className="max-w-6xl mx-auto px-4 py-24 text-center text-ink/50 text-sm">
        Loading…
      </div>
    );
  }

  return <>{children}</>;
}
