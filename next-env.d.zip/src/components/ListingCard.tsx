import Link from 'next/link';
import Image from 'next/image';
import type { Listing } from '@/types';

const CONDITION_LABEL: Record<Listing['condition'], string> = {
  new: 'New',
  used: 'Used',
  'like-new': 'Like New',
  free: 'Free',
  wanted: 'Wanted',
};

function formatPrice(price: number, currency: string, condition: string) {
  if (condition === 'free') return 'Free';
  if (condition === 'wanted') return 'Wanted';
  return `${currency === 'EUR' ? '€' : currency}${price.toLocaleString()}`;
}

function timeAgo(ts: number) {
  const days = Math.floor((Date.now() - ts) / 86_400_000);
  if (days <= 0) return 'Listed today';
  if (days === 1) return 'Listed yesterday';
  if (days < 7) return `Listed ${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `Listed ${weeks}w ago`;
  return `Listed ${Math.floor(days / 30)}mo ago`;
}

function initials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

export default function ListingCard({ listing }: { listing: Listing }) {
  const cover = listing.images?.[0];

  return (
    <Link
      href={`/listing/${listing.id}`}
      className="card group overflow-hidden flex flex-col hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200"
    >
      <div className="relative aspect-square bg-forest-50 overflow-hidden">
        {cover ? (
          <Image
            src={cover}
            alt={listing.title}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover group-hover:scale-[1.05] transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-forest-400 text-sm">
            No photo
          </div>
        )}
        {listing.section === 'leaving-pau' ? (
          <span className="ribbon">{listing.cohort || 'Leaving PAU'}</span>
        ) : listing.condition === 'free' ? (
          <span className="ribbon-free">Free</span>
        ) : listing.deliveryAvailable ? (
          <span className="ribbon-free">Delivery</span>
        ) : null}
      </div>
      <div className="p-3.5 flex flex-col gap-2 flex-1">
        <h3 className="text-sm font-medium text-ink leading-snug line-clamp-2 min-h-[2.5em]">
          {listing.title}
        </h3>
        <div className="flex items-center justify-between mt-auto">
          <span className="price">
            {formatPrice(listing.price, listing.currency, listing.condition)}
          </span>
          <span className="tag">{CONDITION_LABEL[listing.condition]}</span>
        </div>
        <div className="flex items-center justify-between border-t border-ink/5 pt-2">
          <span className="flex items-center gap-1.5 text-xs text-ink/50 min-w-0">
            <span className="w-4 h-4 rounded-full bg-forest-100 text-forest-600 text-[9px] font-semibold flex items-center justify-center shrink-0">
              {initials(listing.sellerName)}
            </span>
            <span className="truncate">{listing.location}</span>
          </span>
          <span className="text-[11px] text-ink/40 shrink-0">{timeAgo(listing.createdAt)}</span>
        </div>
      </div>
    </Link>
  );
}
